import { StyleSheet} from 'react-native';
import LoginScreen from './src/login/LoginScreen';
import RegisterScreen from './src/register/RegisterScreen';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import UpcomingIpo from './src/upcomingIpo/UpcomingIpo';

const Stack = createStackNavigator();

export default function App() {
  return (
    <>
    <NavigationContainer>
    <Stack.Navigator initialRouteName='Login'
        screenOptions={{
          headerTitle: 'Upcoming IPOs',
          headerTitleAlign: 'center',
          headerStyle: {
            backgroundColor: '#fb5b5a', // You can set the background color here
          },
          headerTintColor: '#000', // You can set the text color here
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="UpcomingIpo" component={UpcomingIpo} />
        <Stack.Screen name="Register" component={RegisterScreen} />
      </Stack.Navigator>
  </NavigationContainer>
  </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
});
