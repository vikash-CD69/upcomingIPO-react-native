import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';


const UpcomingIpo = () => {
  const [ipoData, setIpoData] = useState([]);
  const [currencyRates, setCurrencyRates] = useState({});
  const [loading, setLoading] = useState(true);
  const API_TOKEN = 'sk_9cd7c71b0ca54da5938656722fd10be3';

  useEffect(() => {
    const fetchIPOs = async () => {
      try {
        const response = await fetch(
          `https://api.iex.cloud/v1/data/CORE/UPCOMING_IPOS/market?token=${API_TOKEN}`
        );
        const data = await response.json();
        setIpoData(data);
        console.log(data);
      } catch (error) {
        console.error('Error fetching IPO data:', error);
      }
    };

    const fetchCurrencyRates = async () => {
      try {
        const response = await fetch(
          `https://api.iex.cloud/v1/fx/latest?symbols=USDCAD,GBPUSD,USDJPY&token=${API_TOKEN}`
        );
        const data = await response.json();
        setCurrencyRates(data);
      } catch (error) {
        console.error('Error fetching currency rates:', error);
      }
    };

    Promise.all([fetchIPOs(), fetchCurrencyRates()])
      .then(() => setLoading(false))
      .catch(() => setLoading(false));
  }, []);

  return (
    <ScrollView style={{ flex: 1, padding: 20, backgroundColor:"#003f5c" }}>
      <Text style={{ fontSize: 24, textAlign: 'center', marginBottom: 20, fontWeight: 'bold', color: 'white' }}>
        Upcoming IPOs and Currency Exchange Rates
      </Text>

      {loading ? (
        <Text style={{ textAlign: 'center', fontStyle: 'italic', color: 'white' }}>
          Loading...
        </Text>
      ) : (
        <>
          <View style={{ marginBottom: 40 }}>
            <Text style={{ fontSize: 20, marginBottom: 15, fontWeight: 'bold', color: 'black',textDecorationLine: 'underline'}}>UPCOMING IPOs</Text>
            {ipoData.map((ipo) => (
              <View key={ipo.symbol} style={{ marginBottom: 10 , color: 'white'}}>
                <Text style={{ fontWeight: 'bold', color: 'white' }}>{ipo.companyName}</Text>
                <Text style={{color: '#fb5b5a' }}>Expected Date: {ipo.updated}</Text>
                <Text style={{color: '#fb5b5a' }}>Status: {ipo.status}</Text>
                <Text style={{color: '#fb5b5a' }}>Volume: {ipo.volume}</Text>
                <Text style={{color: '#fb5b5a' }}>Price Range: $ {ipo.priceRangeLow} - {ipo.priceRangeHigh}</Text>
                <Text>{ipo.details}</Text>
              </View>
            ))}
          </View>

          <View>
            <Text style={{ fontSize: 20, marginBottom: 15,fontWeight: 'bold', color: 'black',textDecorationLine: 'underline' }}>Currency Exchange Rates</Text>
            {Object.entries(currencyRates).map(([symbol, data]) => (
              <View key={symbol} style={{ marginBottom: 5 }}>
                <Text style={{ fontWeight: 'bold',color: 'white' }}>{currencyRates[symbol].symbol}</Text>
                <Text style={{color: '#fb5b5a' }}>{data.rate}</Text>
              </View>
            ))}
          </View>
        </>
      )}
    </ScrollView>
  );
};

export default UpcomingIpo;
