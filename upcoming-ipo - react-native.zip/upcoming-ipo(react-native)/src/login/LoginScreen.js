import React, { useState } from 'react';
import { StyleSheet, View, TextInput, TouchableOpacity, Text } from 'react-native';

const LoginScreen = ({navigation}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Add your login logic here
    console.log(`Username: ${username}, Password: ${password}`);
    navigation.navigate('UpcomingIpo')
    // For demo purposes, logging the username and password
  };
  const goToRegister = () => {
    navigation.navigate('Register'); // Navigate to the Login page
  };
  return (
    <View style={styles.container}>
      <Text style={styles.logo}>Login</Text>
      <View style={styles.inputView}>
        <TextInput
          style={styles.inputText}
          placeholder="Username"
          placeholderTextColor="#fff"
          onChangeText={(text) => setUsername(text)}
        />
      </View>
      <View style={styles.inputView}>
        <TextInput
          secureTextEntry
          style={styles.inputText}
          placeholder="Password"
          placeholderTextColor="#fff"
          onChangeText={(text) => setPassword(text)}
        />
      </View>
      <TouchableOpacity style={styles.loginBtn} onPress={handleLogin}>
        <Text style={styles.loginText}>LOGIN</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={goToRegister}>
        <Text style={styles.loginRedirect}>Create an account. Register</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#013f5c',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    fontWeight: 'bold',
    fontSize: 55,
    color: '#fb6b5a',
    marginBottom: 40,
  },
  inputView: {
    width: '80%',
    backgroundColor: '#465881',
    borderRadius: 35,
    height: 60,
    marginBottom: 20,
    justifyContent: 'center',
    padding: 30,
  },
  inputText: {
    height: 50,
    color: 'yellow',
  },
  loginBtn: {
    width: '90%',
    backgroundColor: '#fb4g5a',
    borderRadius: 35,
    height: 55,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 45,
    marginBottom: 15,
  },
  loginText: {
    color: 'yellow',
  },
  loginRedirect: {
    color: 'yellow',
    marginTop: 25,
  },
});

export default LoginScreen;
